<?php

	$db = new PDO("mysql:host=localhost;port=3307;dbname=phpdbc", "ssh", "0626");

	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$score = [
    [1, "홍길동", "경기도 성남시","010-1234-1234"],
    [2, "이순신", "경기도 광주시","010-1234-5678"],
    [3, "강감찬", "서울 특별시", "010-5678-1234"]];
	/*for($i = 0 ; $i<count($score);$i++){
		$num  = $score[$i][0];
		$name = $score[$i][1];
		$addr  = $score[$i][2];
		$tel  = $score[$i][3];

		$sql  = "insert into addrbook values($num,'$name','$addr','$tel')";
		$db->exec($sql);
	}*/
	/*$sql = "create table addrbook(
		num  int primary key,
		name varchar(20),
		addr varchar(20),
		tel varchar(20)
		)";
	$db->exec($sql);*/
	$sql  = "select * from addrbook";
	$query = $db->query($sql);
	echo "<table>";
    while ($row = $query->fetch()) {
        echo "<tr>";
        echo "<td>", $row["num"],  "</td>";
        echo "<td>", $row["name"], "</td>";
        echo "<td>", $row["addr"],  "</td>";
        echo "<td>", $row["tel"],  "</td>";
        echo "</tr>";
    }
	echo "</table>";
?>
