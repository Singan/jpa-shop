package jpabook.jpashop.domain.en;

public enum Orderstatus {
    Order,Cancel
}
