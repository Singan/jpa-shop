<?php 
	$kor = 80;
	$eng = 90;
	$math = 70;
	$art = 20;
	$arr = array($kor,$eng,$math,$art);
	$max = 0;
	$sum = 0;
	$avg = 0;
	foreach($arr as $a){
		echo $a , "<br>";
		if($max<=$a)
			$max = $a;
		$sum +=$a;
	}
	echo "총합 <br>",$sum;
	echo "평균 <br>",$sum/count($arr);
	echo "최고값 <br>",$max;
?>