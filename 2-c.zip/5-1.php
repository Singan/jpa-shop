<?php
	$param1 = $_GET['name'];

	echo $param1 ;
 ?>