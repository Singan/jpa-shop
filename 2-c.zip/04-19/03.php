<?php
	function sum($start,$end){
		$result = 0;
		for($i = $start;$i<=$end;$i++){
			$result +=$i;
		}
		
		return $result;
	}

?>


<?php
	$n = 5;
	echo sum(10,20),"<br>";
	echo sum(50,60), "<br>";
	echo sum(10,20)+sum(50,60);
?>

