<?php
	$a = 1;
	function test($a) { 
		echo "(1) $a<br>"; //파라미터 $a 출력
		
		echo "(2) $GLOBALS[a]<br>"; //전역변수 $a 출력
	} 
	test(2);
	echo "(3) $a<br>" //전역변수 $a 출력
?>