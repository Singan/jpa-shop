<!doctype html>
 <html>
 <head>
     <meta charset="utf-8">
     <style>
         table { width: 400px; text-align: center; }
         th    { background-color: cyan; }
     </style>
 </head>
 <body>
 
 <table>
     <tr>
         <th>번호</th><th>이름</th>
         <th>국어</th><th>영어</th><th>수학</th>
         <th>총점</th><th>평균</th>
     </tr>



<?php
	class Score{
		public $num ,$name,$kor,$eng,$math;
		public function setInfo($num,$name,$kor,$eng,$math){
			$this->num = $num;
			$this->name = $name;
			$this->kor = $kor;
			$this->eng = $eng;
			$this->math = $math;
		}
		
	}
?>
<?php

	$db = new PDO("mysql:host=localhost;port=3307;dbname=phpdbc", "ssh", "0626");
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$score = [
    [1, "홍길동", 50, 60, 70],
    [2, "이순신", 65, 75, 85],
    [3, "강감찬", 60, 80, 70]];
	/*for($i = 0 ; $i<count($score);$i++){
		$num  = $score[$i][0];
		$name = $score[$i][1];
		$kor  = $score[$i][2];
		$eng  = $score[$i][3];
		$math = $score[$i][4];

		$sql  = "insert into score(num,name,kor,eng,math) values($num,'$name',$kor,$eng,$math)";
		$db->exec($sql);
	}*/
	$sql  = "select * from score";
	$query = $db->query($sql);
	$query->setFetchMode(PDO::FETCH_CLASS, 'Score');
	$result = $query->fetchAll();
    foreach($result as $score){
        echo "<tr>";
        echo "<td>", $score->num,  "</td>";
        echo "<td>", $score->name, "</td>";
        echo "<td>", $score->kor,  "</td>";
        echo "<td>", $score->eng,  "</td>";
        echo "<td>", $score->math, "</td>";
        
        $sum = $score->kor + $score->eng + $score->math;
        echo "<td>", $sum, "</td>";
        echo "<td>", number_format($sum / 3, 2), "</td>";
        echo "</tr>";
    }
	echo "</table>";

?>
</body>
</html>
