<?php
	function test($a,$y){
		return 10 * $a + $y;
	}

?>


<?php
	$n = 4;
	echo test($n,9);
	
?>

