<?php
	function test($a){
		for($i=1;$i<=$a;$i++){
			for($j=1;$j<=$i;$j++){
				echo "*";
			}
			echo("<br>");
		}
	}

?>


<?php
	$n = 4;
	test($n)
	
?>

