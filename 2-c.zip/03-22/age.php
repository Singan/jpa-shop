	<?php 
		$age = $_REQUEST["age"];
		$pay = $age<=7||$age>=60 ? 2500:5000;
		echo $pay."원";
	?>