<?php
	$hak = $_REQUEST["hak"];
	$data = [
		["101", "102", "103", "104", "105"],
		["111-2222", "234-5678", "346-3353", "223-4633", "242-4532"]
	];
	$i = 0;
	for(;$i<count($data[0]);$i++){
		echo $data[0][$i],"<br>";
		if($data[0][$i]==$hak)
			break;
	};
	
	if($i<count($data[1])){
		echo $data[1][$i];
	}else{
		echo "그런사람 없습니다";
	}
?>