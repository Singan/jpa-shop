<?php
	class Student
	{
		private $no,$name,$kor,$eng,$math;
		public function __construct($no,$name,$kor,$eng,$math){
			$this->no = $no;
			$this->name = $name;
			$this->kor = $kor;
			$this->eng = $eng;
			$this->math = $math;
		}

		public function printScore(){
			echo "
			$this->no 번 <br>이름: $this->name <br> 국어: $this->kor <br> 영어: $this->eng <br> 수학: $this->math <br>";
		}

	}
	$s1 = new Student(1,"석성희",100,100,100);
	$s2 = new Student(2,"하종찬",10,20,30);
	
	
	$s1->printScore();
	$s2->printScore();
?>
