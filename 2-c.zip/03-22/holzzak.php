	<?php 
		$count =0;
		$sum = 0;
		while($count<=40){
			if($count%2==0&&$count>=20)
				echo $count ,"는 짝수 <br>";
			if(10<=$count&&$count<=30)
				$sum += $count;
			$count++;
		}
		echo $sum ,"은 10~30 의 합<br>";
		$sum = 0;
		for($i = 0; $i<=40;$i++){
			if($i%2==0&&$i>=20)
				echo $i ,"는 짝수 <br>";
			if(10<=$i&&$i<=30)
				$sum += $i;
		}
		echo $sum ,"은 10~30 의 합";
		$i = 1;
		while (true)  {
		 
			echo "$i ";

			if($i>=10)
				break;
			$i++;
		}

	?>
	