	<?php 
		$year = $_REQUEST["year"];
		if((($year %4 ==0) && ($year %100 !=0))||$year %400 == 0){
			echo "윤달";}
		else{
			echo "비윤달";
		}
	?>