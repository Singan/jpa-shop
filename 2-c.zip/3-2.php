 <!doctype html>
 <html>
 <head>
     <meta charset="utf-8">
 </head>
 <body>
	 <?php
		$kor = $_REQUEST["kor"];
		$eng = $_REQUEST["eng"];
		$math = $_REQUEST["math"];
		$total = $kor+$eng+$math;
	?>
	<!-- -->
	
	 <?php
		echo $kor,"</br>";
		echo $eng ,"</br>";
		echo $math ,"</br>";
		echo "총합 =" , $total,"<br>";
		echo "평균 =" , round($total/3,2),"<br>";	
	 ?>

 <br>
 
 
 </body>
 </html>
