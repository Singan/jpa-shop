package jpabook.jpashop.domain.en;

public enum DeliveryStatus {
    READY,COMP
}
