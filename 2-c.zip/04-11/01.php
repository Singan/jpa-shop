<?php?
	function test($a){
		for($i=0;$i<$a;i++){
			echo $i;
		}
	}

>


<?php
	$n = 4;
	test($n)
	
?>

