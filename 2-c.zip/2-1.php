 <!doctype html>
 <html>
 <head>
     <meta charset="utf-8">
 </head>
 <body>
	 <?php
			$a =25;
			$b =10;
			function abc(){
			$a =25;
			$b =10;
				return $a*$b;
			}
	?>
	<!-- -->
	
	 <?php
			// 한줄주석
			/*
				여러줄 주석
			*/
		  echo " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;공백을 5개 찍고 이 문장이 시작됩니다.<br>
			이 문장은 중간에 공백이 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5개 있습니다.<br>";

			
	 ?>
	25+10=
	 <?=

			 $a+$b,"<br>";
			 
	 ?>
	 25*10=
	 <?php
		
			echo abc();
			 

	 ?>
 <br>
 
 
 </body>
 </html>
