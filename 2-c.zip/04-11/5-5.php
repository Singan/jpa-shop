<?php
	//$name = isset($_REQUEST["name"]) ?$_REQUEST["name"]:"" ;
	//$lang = isset($_REQUEST["lang"]) ?$_REQUEST["lang"]:"" ;
	//$hobby = isset($_REQUEST["hobby"]) ?$_REQUEST["hobby"]:"" ;
	echo "아이디 : ",   $_REQUEST["id"]??"",     "<br>";
    echo "비밀번호 : ", $_REQUEST["pw"]??"",     "<br>";
    echo "성별 : ",     $_REQUEST["gender"]??"", "<br>";
    echo "취미 : ",     $_REQUEST["hobby2"]??"",  "<br>";
    echo "주소 : ",     $_REQUEST["addr"]??"",   "<br>";
    echo "메모 : ",     $_REQUEST["memo"]??"",   "<br>";
	$name = $_REQUEST["name"]??"";
	echo "이름",$name,"<br>";
	if(isset($_REQUEST["lang"]) ){
		echo "언어:";
		$lang = $_REQUEST["lang"];
		foreach($lang as $a){
			echo $a,"  ";
		}
	}
	if(isset($_REQUEST["hobby"])){
		echo "<br>취미:";
		$hobby =$_REQUEST["hobby"];
		foreach($hobby as $a){		
			echo $a,"  ";
		}
	}
?>