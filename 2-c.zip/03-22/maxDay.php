	<?php 
	$a = 0;
	$month = $_REQUEST["month"];
	$year = $_REQUEST["year"];
	
	switch($month){
		case 1:case 3:case 5:case 7:case 8:case 10:case 12:
			$a=31;
			break;
		case 4:case 6:case 9:case 11:
			$a=30;
			break;
		case 2:
			if((($year %4 ==0) && ($year %100 !=0))||$year %400 == 0){
				//윤달
				$a = 29;
			}else{
				$a=28;
			}
			break;
	}
	
		echo $month,"월 달의 일수는 " ,$a ,"일 입니다";
	?>